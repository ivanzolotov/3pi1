﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
class MainClass
{
    public static void Main(string[] args)
    {
        
        string path = AppDomain.CurrentDomain.BaseDirectory;
        List<string> actualIDs = File.ReadAllLines(path + "actual.txt").ToList();

        List<string> clearIDs = new List<string>();
        foreach (string elem in actualIDs)
        {
            clearIDs.Add(elem.Replace("\n", ""));
        }

        List<string> htmlFiles = new List<string>();
        foreach (string file in Directory.GetFiles(path, "*.html", SearchOption.AllDirectories))
        {
            htmlFiles.Add(Path.GetFileNameWithoutExtension(file).Replace("0", ""));
        }

        List<string> fileNameIDs = new List<string>();
        foreach (string htmlFile in htmlFiles)
        {
            fileNameIDs.Add(htmlFile.Replace(".html", "").Replace(".en", ""));
        }

        Dictionary<string, int> preFinalData = new Dictionary<string, int>();
        foreach (string clearID in clearIDs)
        {
            foreach (string id in fileNameIDs)
            {
                if (id == clearID)
                {
                    if (preFinalData.ContainsKey(id))
                    {
                        preFinalData[id]++;
                    }
                    else
                    {
                        preFinalData[id] = 1;
                    }
                }
            }
        }
        List<string> finalData = new List<string>();
        foreach (KeyValuePair<string, int> item in preFinalData)
        {
            if (item.Value == 1)
            {
                finalData.Add(item.Key);
            }
        }

        Console.WriteLine("Files, that you need to translate:");
        foreach (string id in finalData)
        {
            Console.WriteLine(id);
        }

        File.WriteAllLines("result.txt", finalData);
    }
}
